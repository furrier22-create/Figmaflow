using System.Collections.Generic;
using UnityEngine.UIElements;

namespace FigmaRuntime
{
    /// <summary>
    /// Az OverlayBinder feladata �sszek�tni
    /// a Transition Track-eket a RenderPair-ekkel.
    ///
    /// Nem anim�l.
    /// Nem m�dos�tja a Motion Engine-t.
    /// Csak a renderel�si �letciklust kezeli.
    /// </summary>
    public class OverlayBinder
    {
        private readonly VisualElement root;

        private readonly List<ElementTrack> boundTracks =
            new();

        public OverlayBinder(VisualElement root)
        {
            this.root = root;
        }

        public void Bind(Transition transition)
        {
            UnbindInternal();

            if (transition == null)
                return;

            foreach (ElementTrack track in transition.Tracks)
            {
                if (track == null)
                    continue;

                boundTracks.Add(track);

                if (!track.HasRenderPair)
                {
                    // Layout fallback
                    track.HideSource();
                    continue;
                }

                OverlayRenderPair pair = track.RenderPair;

                pair.Current?.Hide();
                pair.Target?.Hide();

                // Egyel�re tov�bbra is a Current elemet anim�ljuk.
                // A k�vetkez� l�p�sben itt fogjuk �tir�ny�tani
                // az anim�ci�s reprezent�ci�ra.
                track.Target = pair.Current?.Element;
            }
        }

        public void Unbind(Transition transition)
        {
            UnbindInternal();
        }

        private void UnbindInternal()
        {
            foreach (ElementTrack track in boundTracks)
            {
                if (track == null)
                    continue;

                if (!track.HasRenderPair)
                {
                    track.ShowSource();
                    continue;
                }

                OverlayRenderPair pair = track.RenderPair;

                pair.Current?.Show();
                pair.Target?.Show();
            }

            boundTracks.Clear();
        }
    }
}