using UnityEngine;

namespace FigmaRuntime
{
    public enum AnimationMode
    {
        Layout,
        Overlay
    }

    public enum EaseType
    {
        Linear,

        EaseIn,
        EaseOut,
        EaseInOut,

        EaseInBack,
        EaseOutBack,
        EaseInOutBack,

        Gentle,
        Quick,
        Bouncy,
        Slow,

        CustomBezier,
        CustomSpring
    }

    [CreateAssetMenu(menuName = "FigmaFlow/Profile")]
    public class FigmaFlowProfile : ScriptableObject
    {
        [Header("Animation")]

        public AnimationMode animationMode =
            AnimationMode.Layout;

        public EaseType easing =
            EaseType.EaseInOut;

        public float duration = 0.6f;

        [Header("Tolerance")]

        public float positionTolerance = 1f;
        public float sizeTolerance = 1f;
        public float opacityTolerance = 0.01f;
    }
}