using UnityEngine.UIElements;

namespace FigmaRuntime
{
    /// <summary>
    /// A VisualElement hierarchia k�z�s seg�doszt�lya.
    ///
    /// Minden runtime komponens ugyanazt a
    /// logikai gy�keret �s �tvonal-kezel�st haszn�lja.
    /// </summary>
    public static class VisualTreeUtility
    {
        /// <summary>
        /// A Figma logikai gy�kere.
        ///
        /// A TemplateContainer alatt �ltal�ban
        /// egyetlen Desktop/Root elem tal�lhat�.
        /// A runtime mindenhol innen dolgozik.
        /// </summary>
        public static VisualElement GetLogicalRoot(
            VisualElement root)
        {
            if (root == null)
                return null;

            // TemplateContainer -> Desktop
            if (root.childCount == 1)
                return root[0];

            return root;
        }

        /// <summary>
        /// Path alap� keres�s.
        /// </summary>
        public static VisualElement FindByPath(
            VisualElement root,
            string path)
        {
            root = GetLogicalRoot(root);

            if (root == null)
                return null;

            if (string.IsNullOrWhiteSpace(path))
                return null;

            string[] parts = path.Split('/');

            VisualElement current = root;

            foreach (string part in parts)
            {
                if (string.IsNullOrWhiteSpace(part))
                    continue;

                current = FindDirectChild(
                    current,
                    part);

                if (current == null)
                    return null;
            }

            return current;
        }

        /// <summary>
        /// K�zvetlen gyermek keres�se n�v alapj�n.
        /// </summary>
        public static VisualElement FindDirectChild(
            VisualElement parent,
            string childName)
        {
            if (parent == null)
                return null;

            foreach (VisualElement child in parent.Children())
            {
                if (child.name == childName)
                    return child;
            }

            return null;
        }

        /// <summary>
        /// Runtime �tvonal el��ll�t�sa.
        /// </summary>
        public static string GetPath(
            VisualElement element)
        {
            if (element == null)
                return string.Empty;

            string path = element.name;

            VisualElement current = element.parent;

            while (current != null)
            {
                if (!string.IsNullOrEmpty(current.name))
                {
                    path = current.name + "/" + path;
                }

                current = current.parent;
            }

            return path;
        }
    }
}