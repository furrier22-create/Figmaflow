using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UIElements;

namespace FigmaRuntime
{
    public class ElementTrack
    {
        private VisualElement target;

        private readonly ElementData from;
        private readonly ElementData to;

        private readonly List<IPropertyTrack> tracks = new();

        private readonly AnimatedProperties properties;

        private readonly EaseType ease;

        private readonly AnimationCurve customCurve;

        private OverlayRenderPair renderPair;

        public float Delay { get; }

        public float Duration { get; }

        /// <summary>
        /// Az eredeti Layout elem.
        /// </summary>
        public VisualElement Source { get; }

        /// <summary>
        /// Az aktu�lisan anim�lt elem.
        /// Layout m�dban megegyezik a Source-szal.
        /// Overlay m�dban k�s�bb �tir�ny�that�.
        /// </summary>
        public VisualElement Target
        {
            get => target;
            set
            {
                if (target == value)
                    return;

                target = value;
                RebuildTracks();
            }
        }

        /// <summary>
        /// Overlay m�dban a Builder rendelheti hozz�.
        /// Layout m�dban null marad.
        /// </summary>
        public OverlayRenderPair RenderPair
        {
            get => renderPair;
            set => renderPair = value;
        }

        public bool HasRenderPair => renderPair != null;

        public ElementTrack(
            VisualElement visual,
            ElementData from,
            ElementData to,
            AnimatedProperties properties,
            float delay,
            float duration,
            EaseType ease,
            AnimationCurve customCurve)
        {
            Source = visual;
            target = visual;

            this.from = from;
            this.to = to;

            this.properties = properties;

            Delay = Mathf.Max(0f, delay);
            Duration = Mathf.Max(0.01f, duration);

            this.ease = ease;
            this.customCurve = customCurve;

            RebuildTracks();
        }

        private void RebuildTracks()
        {
            tracks.Clear();

            if (target == null)
                return;

            if ((properties & AnimatedProperties.Position) != 0)
            {
                tracks.Add(
                    new PositionTrack(
                        target,
                        from,
                        to));
            }

            if ((properties & AnimatedProperties.Size) != 0)
            {
                tracks.Add(
                    new SizeTrack(
                        target,
                        from.worldRect,
                        to.worldRect));
            }

            if ((properties & AnimatedProperties.Opacity) != 0)
            {
                tracks.Add(
                    new OpacityTrack(
                        target,
                        from.opacity,
                        to.opacity));
            }
        }

        public void Evaluate(float globalTime)
        {
            if (globalTime < Delay)
            {
                foreach (var track in tracks)
                    track.Evaluate(0f);

                return;
            }

            float localTime = globalTime - Delay;

            float t = Mathf.Clamp01(localTime / Duration);

            t = MotionUtility.Evaluate(
                ease,
                t,
                customCurve);

            foreach (var track in tracks)
                track.Evaluate(t);
        }

        public void HideSource()
        {
            if (Source == null)
                return;

            Source.style.visibility = Visibility.Hidden;
        }

        public void ShowSource()
        {
            if (Source == null)
                return;

            Source.style.visibility = Visibility.Visible;
        }

        public void Reset()
        {
            foreach (var track in tracks)
                track.Reset();
        }
    }
}