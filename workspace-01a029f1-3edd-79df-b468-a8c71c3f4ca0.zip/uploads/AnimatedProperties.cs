namespace FigmaRuntime
{
    [System.Flags]
    public enum AnimatedProperties
    {
        None = 0,
        Position = 1,
        Size = 2,
        Opacity = 4
    }
}