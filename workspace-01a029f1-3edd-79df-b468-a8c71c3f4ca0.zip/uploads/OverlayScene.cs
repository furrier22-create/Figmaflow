using UnityEngine;
using UnityEngine.UIElements;

namespace FigmaRuntime
{
    public class OverlayScene : MonoBehaviour
    {
        private const string OverlayRootName = "FigmaFlow-OverlayRoot";

        private VisualElement documentRoot;
        private VisualElement overlayRoot;

        private TemplateContainer current;
        private TemplateContainer target;

        private OverlayLayer overlayLayer;

        private readonly OverlayRenderer renderer =
            new OverlayRenderer();

        public TemplateContainer Current => current;
        public TemplateContainer Target => target;

        public VisualElement CurrentRoot => current;
        public VisualElement TargetRoot => target;

        public OverlayLayer Layer => overlayLayer;

        public void InitializeRoot(VisualElement rootElement)
        {
            documentRoot = rootElement;

            overlayRoot = documentRoot.Q<VisualElement>(OverlayRootName);

            if (overlayRoot == null)
            {
                overlayRoot = new VisualElement
                {
                    name = OverlayRootName
                };

                overlayRoot.style.position = Position.Absolute;
                overlayRoot.style.left = 0;
                overlayRoot.style.top = 0;
                overlayRoot.style.right = 0;
                overlayRoot.style.bottom = 0;

                documentRoot.Add(overlayRoot);
            }

            overlayLayer ??= new OverlayLayer();
            overlayLayer.Attach(overlayRoot);
        }

        public void Initialize(
            VisualTreeAsset currentTree,
            VisualTreeAsset targetTree)
        {
            if (overlayRoot == null)
            {
                UnityEngine.Debug.LogError(
                    "[FigmaFlow] OverlayScene has no OverlayRoot.");

                return;
            }

            overlayRoot.Clear();

            current = Create(currentTree, true);
            target = Create(targetTree, false);

            overlayRoot.Add(current);
            overlayRoot.Add(target);

            overlayLayer.Attach(overlayRoot);
        }

        public OverlayRenderData Build(
            TransitionAnalysis analysis)
        {
            if (analysis == null)
                return new OverlayRenderData();

            return renderer.Build(
                analysis,
                current,
                target);
        }

        public void Commit(
            VisualTreeAsset nextTarget)
        {
            if (overlayRoot == null)
                return;

            current?.RemoveFromHierarchy();

            current = target;

            current.style.visibility = Visibility.Visible;
            current.style.position = Position.Relative;

            target = Create(nextTarget, false);

            overlayRoot.Add(target);

            overlayLayer.Attach(overlayRoot);
            overlayLayer.Clear();
        }

        private TemplateContainer Create(
            VisualTreeAsset tree,
            bool visible)
        {
            TemplateContainer container = tree.Instantiate();

            if (visible)
            {
                container.style.visibility = Visibility.Visible;
                container.style.position = Position.Relative;
            }
            else
            {
                container.style.visibility = Visibility.Hidden;
                container.style.position = Position.Absolute;

                container.style.left = -100000;
                container.style.top = -100000;
            }

            return container;
        }
    }
}