﻿#if UNITY_EDITOR

using UnityEditor;
using UnityEngine;
using UnityEngine.UIElements;

namespace FigmaRuntime.Editor
{
    public class FigmaFlowWindow : EditorWindow
    {
        private VisualTreeAsset fromState;
        private VisualTreeAsset toState;

        private FigmaFlowProfile profile;

        private TransitionAsset transitionAsset;

        [MenuItem("Tools/FigmaFlow/Motion Studio")]
        public static void Open()
        {
            GetWindow<FigmaFlowWindow>("FigmaFlow");
        }

        void OnGUI()
        {
            GUILayout.Space(8);

            GUILayout.Label(
                "FigmaFlow Motion Studio",
                EditorStyles.boldLabel);

            GUILayout.Space(8);

            fromState =
                (VisualTreeAsset)EditorGUILayout.ObjectField(
                    "From",
                    fromState,
                    typeof(VisualTreeAsset),
                    false);

            toState =
                (VisualTreeAsset)EditorGUILayout.ObjectField(
                    "To",
                    toState,
                    typeof(VisualTreeAsset),
                    false);

            profile =
                (FigmaFlowProfile)EditorGUILayout.ObjectField(
                    "Profile",
                    profile,
                    typeof(FigmaFlowProfile),
                    false);

            transitionAsset =
                (TransitionAsset)EditorGUILayout.ObjectField(
                    "Transition Asset",
                    transitionAsset,
                    typeof(TransitionAsset),
                    false);

            GUILayout.Space(12);

            GUI.enabled =
                fromState != null &&
                toState != null &&
                profile != null;

            if (GUILayout.Button(
                "Generate Transition Asset",
                GUILayout.Height(32)))
            {
                transitionAsset =
                    TransitionAssetGenerator.Generate(
                        fromState,
                        toState,
                        profile);
            }

            GUI.enabled = true;

            GUILayout.Space(20);

            EditorGUILayout.LabelField(
                "Runtime",
                EditorStyles.boldLabel);

            GUI.enabled =
                transitionAsset != null &&
                FigmaFlowRuntime.HasAnalysis;

            if (GUILayout.Button(
                "Import Runtime Analysis",
                GUILayout.Height(32)))
            {
                TransitionAssetBuilder.Fill(
                    transitionAsset,
                    FigmaFlowRuntime.CurrentAnalysis.Candidates);

                EditorUtility.SetDirty(
                    transitionAsset);

                AssetDatabase.SaveAssets();
                AssetDatabase.Refresh();

                Selection.activeObject =
                    transitionAsset;
            }

            GUI.enabled = true;

            GUILayout.Space(8);

            if (FigmaFlowRuntime.HasAnalysis)
            {
                EditorGUILayout.HelpBox(
                    $"Runtime Analysis Ready\nCandidates: {FigmaFlowRuntime.CurrentAnalysis.Candidates.Count}",
                    MessageType.Info);
            }
            else
            {
                EditorGUILayout.HelpBox(
                    "Play Mode-ban futtass egy átmenetet (Next), majd importáld az elemzést.",
                    MessageType.Warning);
            }
        }
    }
}

#endif