using System.Collections;
using System.Diagnostics;
using UnityEngine;
using UnityEngine.UIElements;

namespace FigmaRuntime
{
    [RequireComponent(typeof(FigmaDocumentHost))]
    public class FigmaStateMachine : MonoBehaviour
    {
        [Header("States")]
        public VisualTreeAsset[] states;

        [Header("Profile")]
        public FigmaFlowProfile profile;

        [Header("Motion")]
        public TransitionAsset transitionAsset;

        private FigmaDocumentHost host;
        private ITransitionPlayer player;
        private FigmaStateAsset[] capturedStates;

        private int currentState;
        private int pendingState = -1;

        void Awake()
        {
            host = GetComponent<FigmaDocumentHost>();

            SelectPlayer();
            SubscribePlayer();
        }

        void OnDestroy()
        {
            UnsubscribePlayer();
        }

        void SelectPlayer()
        {
            switch (profile.animationMode)
            {
                case AnimationMode.Layout:
                    player = GetComponent<TransitionPlayer>();
                    break;

                case AnimationMode.Overlay:
                    player = GetComponent<OverlayTransitionPlayer>();
                    break;
            }
        }

        void SubscribePlayer()
        {
            if (player is TransitionPlayer tp)
                tp.Finished += OnTransitionFinished;

            if (player is OverlayTransitionPlayer op)
                op.Finished += OnTransitionFinished;
        }

        void UnsubscribePlayer()
        {
            if (player is TransitionPlayer tp)
                tp.Finished -= OnTransitionFinished;

            if (player is OverlayTransitionPlayer op)
                op.Finished -= OnTransitionFinished;
        }

        IEnumerator Start()
        {
            host.HideRoot();

            capturedStates = new FigmaStateAsset[states.Length];

            for (int i = 0; i < states.Length; i++)
            {
                TemplateContainer live = host.Load(states[i]);

                UnityEngine.Debug.Log($"Load {i}");

                yield return null;

                UnityEngine.Debug.Log($"Capture {i}");

                capturedStates[i] =
                    StateCapture.Capture(
                        live,
                        states[i].name);
            }

            host.Load(states[0]);

            currentState = 0;

            host.ShowRoot();
        }

        [ContextMenu("Next")]
        public void Next()
        {
            GoToState(currentState + 1);
        }

        [ContextMenu("Previous")]
        public void Previous()
        {
            GoToState(currentState - 1);
        }

        [ContextMenu("Go To State 0")]
        public void GoTo0()
        {
            GoToState(0);
        }

        [ContextMenu("Go To State 1")]
        public void GoTo1()
        {
            GoToState(1);
        }

        [ContextMenu("Go To State 2")]
        public void GoTo2()
        {
            GoToState(2);
        }

        public void GoTo(string stateName)
        {
            for (int i = 0; i < states.Length; i++)
            {
                if (states[i].name == stateName)
                {
                    GoToState(i);
                    return;
                }
            }

            UnityEngine.Debug.LogWarning($"State not found: {stateName}");
        }

        public void GoToState(int targetState)
        {
            if (targetState < 0)
                return;

            if (targetState >= states.Length)
                return;

            if (targetState == currentState)
                return;

            StopAllCoroutines();

            StartCoroutine(
                PlayTransition(targetState));
        }

        IEnumerator PlayTransition(int targetState)
        {
            pendingState = targetState;

            TransitionAnalysis analysis =
                TransitionBuilder.Analyze(
                    capturedStates[currentState],
                    capturedStates[targetState]);

            FigmaFlowRuntime.SetAnalysis(
                analysis);

            Transition transition =
                TransitionBuilder.Build(
                    analysis,
                    transitionAsset,
                    host.Current);

            LogTransition(
                analysis,
                transition);

            player.PlayForward(
                transition,
                transition.Duration);

            yield break;
        }

        void OnTransitionFinished()
        {
            if (pendingState < 0)
                return;

            host.CommitState(
                states[pendingState]);

            currentState = pendingState;
            pendingState = -1;
        }

        private void LogTransition(
            TransitionAnalysis analysis,
            Transition transition)
        {
            int candidates =
                analysis?.Candidates?.Count ?? 0;

            int tracks =
                transition?.Count ?? 0;

            int pairs = -1;

            if (FigmaFlowRuntime.HasAnalysis)
            {
                // K�s�bb ide ker�l majd az OverlayRenderer
                // �ltal el��ll�tott Pair sz�m.
                pairs = candidates;
            }

            UnityEngine.Debug.Log(
$@"==========================
FigmaFlow Transition
==========================
From        : {states[currentState].name}
To          : {states[pendingState].name}

Candidates  : {candidates}
Pairs       : {(pairs >= 0 ? pairs.ToString() : "-")}
Tracks      : {tracks}

Duration    : {transition?.Duration:F2}
Player      : {player?.GetType().Name}
==========================");
        }
    }
}