using System;
using System.Collections.Generic;
using UnityEngine;

namespace FigmaRuntime
{
    [CreateAssetMenu(menuName = "FigmaFlow/Transition Asset")]
    public class TransitionAsset : ScriptableObject
    {
        public string fromState;
        public string toState;

        public List<TransitionItem> items = new();
    }

    [Serializable]
    public class TransitionItem
    {
        public string path;

        public bool enabled = true;

        public bool favorite = false;

        public float delay = 0f;

        public float duration = 0.6f;

        public EaseType ease = EaseType.EaseInOut;

        public AnimationMode animationMode =
            AnimationMode.Layout;

        public AnimatedProperties properties;

        public AnimationCurve customCurve =
            AnimationCurve.EaseInOut(0, 0, 1, 1);
    }
}   