using UnityEngine;
using UnityEngine.UIElements;

namespace FigmaRuntime
{
    /// <summary>
    /// Fel�p�ti az Overlay render modellj�t.
    ///
    /// Feladata kiz�r�lag:
    /// - Current / Target p�rok l�trehoz�sa
    /// - OverlayAnimationItem-ek l�trehoz�sa
    ///
    /// Nem anim�l.
    /// Nem m�dos�tja a UI-t.
    /// </summary>
    public class OverlayRenderer
    {
        public OverlayRenderData Build(
            TransitionAnalysis analysis,
            VisualElement currentRoot,
            VisualElement targetRoot)
        {
            OverlayRenderData data = new();

            if (analysis == null ||
                currentRoot == null ||
                targetRoot == null)
            {
                return data;
            }

            currentRoot =
                VisualTreeUtility.GetLogicalRoot(currentRoot);

            targetRoot =
                VisualTreeUtility.GetLogicalRoot(targetRoot);

            foreach (TrackCandidate candidate in analysis.Candidates)
            {
                VisualElement current =
                    VisualTreeUtility.FindByPath(
                        currentRoot,
                        candidate.Path);

                VisualElement target =
                    VisualTreeUtility.FindByPath(
                        targetRoot,
                        candidate.Path);

                if (current == null || target == null)
                {
#if UNITY_EDITOR
                    UnityEngine.Debug.LogWarning(
                        $"[OverlayRenderer] Missing pair: {candidate.Path}");
#endif
                    continue;
                }

                RenderNode currentNode =
                    new RenderNode(current);

                RenderNode targetNode =
                    new RenderNode(target);

                OverlayRenderPair pair =
                    new OverlayRenderPair
                    {
                        Path = candidate.Path,
                        Current = currentNode,
                        Target = targetNode
                    };

                data.Pairs.Add(pair);

                OverlayAnimationItem item =
                    new OverlayAnimationItem
                    {
                        Path = candidate.Path,
                        Current = currentNode,
                        Target = targetNode,

                        // Jelenleg m�g az Original element.
                        // A k�vetkez� commitban ezt fogjuk
                        // Overlay reprezent�ci�ra cser�lni.
                        AnimationElement =
                            currentNode.Element
                    };

                data.AnimationItems.Add(item);
            }

            UnityEngine.Debug.Log(
                $"[FigmaFlow] Overlay pairs      : {data.PairCount}");

            UnityEngine.Debug.Log(
                $"[FigmaFlow] Animation elements : {data.AnimationCount}");

            return data;
        }
    }
}