namespace FigmaRuntime
{
    public class TrackCandidate
    {
        public string Path;

        public ElementData From;

        public ElementData To;

        public AnimatedProperties Properties;
    }
}