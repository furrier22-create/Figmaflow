namespace FigmaRuntime
{
    public interface ITransitionPlayer
    {
        void PlayForward(
            Transition transition,
            float duration);

        void PlayBackward(
            Transition transition,
            float duration);

        bool IsPlaying { get; }
    }
}