namespace FigmaRuntime
{
    public interface IPropertyTrack
    {
        void Evaluate(float t);

        void Reset();

        void Complete();
    }
}