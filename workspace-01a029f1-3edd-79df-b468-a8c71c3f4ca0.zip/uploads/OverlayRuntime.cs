using UnityEngine;
using UnityEngine.UIElements;

namespace FigmaRuntime
{
    /// <summary>
    /// Smart Overlay fut�si koordin�tor.
    ///
    /// Feladata:
    /// - a k�t �l� UI kezel�se
    /// - RenderPair-ek fel�p�t�se
    /// - Overlay Transition l�trehoz�sa
    /// - Commit kezel�se
    ///
    /// Nem tartalmaz anim�ci�s logik�t.
    /// </summary>
    [RequireComponent(typeof(FigmaDocumentHost))]
    [RequireComponent(typeof(OverlayScene))]
    public class OverlayRuntime : MonoBehaviour
    {
        private FigmaDocumentHost host;
        private OverlayScene scene;
        private OverlayRenderer renderer;

        private OverlayRenderData renderData;

        public OverlayScene Scene => scene;

        public OverlayRenderData RenderData => renderData;

        void Awake()
        {
            host = GetComponent<FigmaDocumentHost>();

            scene = GetComponent<OverlayScene>();

            renderer = new OverlayRenderer();

            scene.InitializeRoot(host.Root);
        }

        /// <summary>
        /// El�k�sz�ti a k�t �l� UI-t.
        /// </summary>
        public void Prepare(
            VisualTreeAsset currentTree,
            VisualTreeAsset targetTree,
            TransitionAnalysis analysis)
        {
            scene.Initialize(
                currentTree,
                targetTree);

            renderData =
                renderer.Build(
                    analysis,
                    scene.CurrentRoot,
                    scene.TargetRoot);

            UnityEngine.Debug.Log(
                $"[FigmaFlow] Overlay prepared ({renderData.Count} pairs)");
        }

        /// <summary>
        /// Overlay Transition l�trehoz�sa.
        /// </summary>
        public Transition BuildTransition(
            TransitionAnalysis analysis,
            TransitionAsset asset)
        {
            if (renderData == null)
            {
                UnityEngine.Debug.LogError(
                    "[FigmaFlow] OverlayRuntime: Prepare() must be called before BuildTransition().");

                return new Transition();
            }

            return OverlayTransitionBuilder.Build(
                analysis,
                asset,
                renderData);
        }

        /// <summary>
        /// Anim�ci� v�ge.
        /// </summary>
        public void Commit(
            VisualTreeAsset nextTarget)
        {
            scene.Commit(nextTarget);

            host.SetCurrent(scene.Current);

            UnityEngine.Debug.Log(
                "[FigmaFlow] Overlay commit completed.");
        }

        public void Reset()
        {
            renderData = null;
        }
    }
}