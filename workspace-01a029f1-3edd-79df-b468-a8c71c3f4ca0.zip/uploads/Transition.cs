using System.Collections.Generic;

namespace FigmaRuntime
{
    public class Transition
    {
        private readonly List<ElementTrack> tracks = new();

        public IReadOnlyList<ElementTrack> Tracks => tracks;

        public int Count => tracks.Count;

        public float Duration { get; private set; }

        public void Add(ElementTrack track)
        {
            tracks.Add(track);

            float endTime = track.Delay + track.Duration;

            if (endTime > Duration)
                Duration = endTime;
        }

        public void Evaluate(float time)
        {
            foreach (var track in tracks)
            {
                track.Evaluate(time);
            }
        }

        public void Reset()
        {
            foreach (var track in tracks)
            {
                track.Reset();
            }
        }
    }
}