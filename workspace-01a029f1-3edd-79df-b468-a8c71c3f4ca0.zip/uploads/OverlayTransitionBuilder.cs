using System.Collections.Generic;
using UnityEngine.UIElements;

namespace FigmaRuntime
{
    /// <summary>
    /// Overlay Transition �p�t�.
    ///
    /// A Layout TransitionBuilder-t nem m�dos�tja.
    /// A Transition ugyanaz marad,
    /// csak a Track-ek OverlayRenderPair hivatkoz�st is kapnak.
    /// </summary>
    public static class OverlayTransitionBuilder
    {
        public static Transition Build(
            TransitionAnalysis analysis,
            TransitionAsset asset,
            OverlayRenderData renderData)
        {
            Transition transition = new();

            if (analysis == null ||
                asset == null ||
                renderData == null)
            {
                return transition;
            }

            Dictionary<string, TransitionItem> itemLookup = new();

            foreach (var item in asset.items)
                itemLookup[item.path] = item;

            Dictionary<string, OverlayRenderPair> pairLookup = new();

            foreach (var pair in renderData.Pairs)
                pairLookup[pair.Path] = pair;

            foreach (var candidate in analysis.Candidates)
            {
                if (!itemLookup.TryGetValue(candidate.Path, out var item))
                    continue;

                if (!item.enabled)
                    continue;

                if (!pairLookup.TryGetValue(candidate.Path, out var pair))
                    continue;

                if (pair.Current?.Element == null)
                    continue;

                ElementTrack track = new ElementTrack(
                    pair.Current.Element,
                    candidate.From,
                    candidate.To,
                    candidate.Properties,
                    item.delay,
                    item.duration,
                    item.ease,
                    item.customCurve);

                // A Layout pipeline-ben ez null marad.
                // Overlay m�dban innent�l ismert a renderp�r.
                track.RenderPair = pair;

                transition.Add(track);
            }

            return transition;
        }
    }
}