using UnityEngine.UIElements;

namespace FigmaRuntime
{
    /// <summary>
    /// Egy anim�lhat� Overlay elem le�r�sa.
    ///
    /// Nem anim�l.
    /// Nem renderel.
    /// Nem m�dos�t UI-t.
    ///
    /// Kiz�r�lag �sszek�ti:
    /// - a Current elemet
    /// - a Target elemet
    /// - a k�s�bbi anim�ci�s reprezent�ci�t.
    /// </summary>
    public class OverlayAnimationItem
    {
        /// <summary>
        /// Egyedi �tvonal a dokumentumban.
        /// </summary>
        public string Path;

        /// <summary>
        /// Current UI eleme.
        /// </summary>
        public IRenderNode Current;

        /// <summary>
        /// Target UI eleme.
        /// </summary>
        public IRenderNode Target;

        /// <summary>
        /// A k�s�bbi anim�ci�s reprezent�ci�.
        ///
        /// v0.4 els� l�p�s�ben m�g megegyezik a Current elemmel.
        /// K�s�bb k�l�n VisualElement lesz.
        /// </summary>
        public VisualElement AnimationElement;

        /// <summary>
        /// Anim�ci� alatt akt�v-e.
        /// </summary>
        public bool Active;

        public bool IsReady =>
            Current != null &&
            Target != null;

        public void Begin()
        {
            Active = true;
        }

        public void End()
        {
            Active = false;
        }
    }
}