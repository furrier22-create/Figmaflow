using System.Collections.Generic;

namespace FigmaRuntime
{
    public class OverlayRenderData
    {
        /// <summary>
        /// A Current / Target p�rok.
        /// Ezeket az OverlayRenderer �p�ti fel.
        /// </summary>
        public readonly List<OverlayRenderPair> Pairs =
            new();

        /// <summary>
        /// Az anim�ci� �letciklus�hoz tartoz� elemek.
        /// Ezeket a k�vetkez� l�p�sben fogjuk fel�p�teni.
        /// </summary>
        public readonly List<OverlayAnimationItem> AnimationItems =
            new();

        public int PairCount => Pairs.Count;

        public int AnimationCount => AnimationItems.Count;

        // Visszafel� kompatibilit�s
        public int Count => PairCount;

        public void Clear()
        {
            Pairs.Clear();
            AnimationItems.Clear();
        }
    }
}