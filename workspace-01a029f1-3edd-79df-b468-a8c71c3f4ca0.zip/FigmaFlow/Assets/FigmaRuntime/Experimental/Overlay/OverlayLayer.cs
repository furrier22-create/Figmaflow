using UnityEngine.UIElements;

namespace FigmaRuntime
{
    /// <summary>
    /// Az anim�ci�s elemek k�l�n r�tege.
    ///
    /// Nem r�sze sem a Current,
    /// sem a Target UI-nak.
    /// Csak az anim�ci� idej�re tartalmaz elemeket.
    /// </summary>
    public class OverlayLayer
    {
        private readonly VisualElement root;

        public VisualElement Root => root;

        public OverlayLayer()
        {
            root = new VisualElement
            {
                name = "FigmaFlow-OverlayLayer"
            };

            root.style.position = Position.Absolute;

            root.style.left = 0;
            root.style.top = 0;
            root.style.right = 0;
            root.style.bottom = 0;

            root.style.visibility = Visibility.Visible;

            // Az anim�ci�s r�teg ne fogjon inputot.
            root.pickingMode = PickingMode.Ignore;
        }

        public void Attach(VisualElement parent)
        {
            if (parent == null)
                return;

            if (root.parent == parent)
                return;

            root.RemoveFromHierarchy();

            parent.Add(root);
        }

        public void Clear()
        {
            root.Clear();
        }

        public void Add(VisualElement element)
        {
            if (element == null)
                return;

            root.Add(element);
        }

        public void Remove(VisualElement element)
        {
            if (element == null)
                return;

            if (element.parent == root)
                root.Remove(element);
        }
    }
}